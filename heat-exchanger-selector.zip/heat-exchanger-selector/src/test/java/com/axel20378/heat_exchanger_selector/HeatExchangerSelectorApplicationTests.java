package com.axel20378.heat_exchanger_selector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeatExchangerSelectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
